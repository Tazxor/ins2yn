import {useState, useEffect} from "react";
import PostList from "./PostList";

const Home = () => {

    /*
        Chaque post est un objet :
        post = {
            title: "Mes Vacances !",
            body:"C'est joli l'Aveyron",
            author:"André",
            id:"2"
        }
    */
    const [posts,setPosts] = useState([])

    const deletePost = (id) => {
        const updatePosts = posts.filter(post => post.id !== id);
        setPosts(updatePosts);
    }

    useEffect(() => {
        fetch('http://localhost:8000/posts')
            .then((res) => {
                return res.json()
            })
            .then((data) => {
                setPosts(data)
            })
    },[])

    return(
        <div>
            <h1>Page d'Accueil</h1>
            <PostList 
                posts={posts}
                deletePost={deletePost}
            />

        </div>
    )
}

export default Home;
import {useParams, useHistory} from 'react-router-dom';
import {useState,useEffect} from 'react';
import {BsFillTrashFill} from 'react-icons/bs';
import {GoTrashcan} from 'react-icons/go';
import {FaTrashAlt} from 'react-icons/fa';


/*
    useParams permet d'acceder aux parametres(=element dynamique) de l'url
*/
const PostDetails = () => {
    //id
     const {id} = useParams();

     const [post,setPost] = useState(null);

     const history = useHistory();


     const deletePost = () =>{
        fetch(`http://localhost:8000/posts/${id}`,{
            method:"DELETE"
        })
        .then(() => {
            history.push('/');
        })
     }

     /*
        Exo : Completer deletePost() pour etre redirigé vers la page d'accueil une fois le post supprimé
     */

    /*
        Exo : 

            Creer le bouton "modifier" permettant au click d'afficher le composant EditPost
            (=page permettant de modifier le post)

            Cette page contiendra un formulaire pré-rempli avec les infos du post (title,body,author)

            Pour les modifications :
                => Le title et le body seront directement modifiable
                => Pour l'auteur, il faudra selectionner parmi l'ensemble des auteurs ayant publié un post (utilisez un menu deroulant)

            Vous utiliserez une requete de type "PUT", puis redirigerez vers la page d'accueil

            BONUS : Afficher sans doublons la liste des auteurs


     */

     useEffect(() => {

        // fetch("http://localhost:8000/posts/"+id)//Concatenation methode n°1
        fetch(`http://localhost:8000/posts/${id}`)//Concatenation methode n°2
        .then((res) => {
            return res.json()
        })
        .then((data) => {
            setPost(data)
        })
     },[])

    return(
       <div className="post-details">
        {
            post ? 
            <div>
                <h2>{post.title}</h2>
                <p>Ecrit par {post.author}</p>
                <div>{post.body}</div>

                <div className="button">
                    <button 
                        className="delete"
                        onClick={deletePost}
                    >
                        Supprimer
                        
                        <BsFillTrashFill className='icon'/>
                        </button>
                </div>
            </div>
            : 'Chargement !'
        }
       </div>
    )
}

export default PostDetails;
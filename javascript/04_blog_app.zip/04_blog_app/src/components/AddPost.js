import {useState} from 'react'; 
import {useHistory} from 'react-router-dom';//(1)

/*
    useHistory est un hook permettant d'acceder à l'historique des url visitées.
    Nous nous en servirons pour modifier l'url dans le navigateur afin d'afficher le composant Home.js

    Emploi :
        (1) : Importation
        (2) : Déclaration
        (3) : Utilisation

*/

const AddPost = () => {
    const [title,setTitle] = useState('');
    const [body,setBody] = useState('');
    const [author, setAuthor] = useState('');

    const history = useHistory();//(2)

    const handleSubmit = (e) => {
        e.preventDefault();

        const newPost = {title,body,author};

        console.log(newPost);

        fetch('http://localhost:8000/posts',{
            method:"POST",
            body: JSON.stringify(newPost),//Transforme newPOST en objet JSON
            headers:{"Content-Type":"application/json"}//On indique le format de la donnée que l'on compte ajouter à la BDD
        })
        .then(() => {
            console.log("Nouveau post ajouté !");   
            history.push('/');//(3) Redirige vers Home
        })

    }

    return(
        <div className="add">
            <h2>Ajouter un post</h2>

            <form onSubmit={handleSubmit}>
                <label>Titre :</label>
                <input 
                    type="text" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />

                <label>Corps :</label>
                <textarea
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                ></textarea>

                <label>Auteur :</label>
                <input 
                    type="text"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                />

                <button>Ajouter !</button>
            </form>
        </div>
    )
}

export default AddPost;
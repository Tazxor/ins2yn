const PostList = ({posts, deletePost}) =>{

    return(
        <div>
            {
                posts.map((item,index) => {
                    return ( 
                        <div className="post-preview" key={item.id} >
                            <a href={`/posts/${item.id}`}>
                                <h2>{item.title}</h2>
                                <p>Ecrit par {item.author}</p>
                                {/* <button onClick={function(){deletePost(item.id)}}>Supprimer</button> */}
                            </a>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default PostList;
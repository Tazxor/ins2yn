import Navbar from "./components/Navbar";
import Home from "./components/Home";
import AddPost from "./components/AddPost";
import PostDetails from "./components/PostDetails";
import { BrowserRouter, Route, Switch } from 'react-router-dom';

/*
  Le routage est la possibilité d'afficher différentes pages au sein de notre application.
  Nous utiliserons react-router pour associer une url(=route) à un composant.
   
*/
function App() {
  return (
    <BrowserRouter>
      <div className="App">

        <Navbar/>

        <div className="content">
          <Switch>

            <Route exact path="/">
              <Home/>
            </Route>
            <Route exact path="/add">
              <AddPost/>
            </Route>
            {/* :id siginifie que "id" est un parametre (=element dynamique) de l'url */}
            <Route exact path='/posts/:id'>
              <PostDetails/>
            </Route>

          </Switch>
        </div>

      </div>
    </BrowserRouter>
  );
}

export default App;
